const gulp = require('gulp');
const sass = require('gulp-sass');
const uglifycss = require('gulp-uglifycss');
let uglify = require('gulp-uglify-es').default;
var htmlmin = require('gulp-html-minifier2');

let filesToMove = [
  "./src/assets/**/*",
  "./src/mocks/*"
]

gulp.task('move', async function () {
  return gulp.src(filesToMove, { base: '.' })
    .pipe(gulp.dest('./dist/'));
});

gulp.task('sass', function () {
  return gulp.src('./src/*.scss')
    .pipe(sass())
    .pipe(gulp.dest('dist/src'))
})

gulp.task('css', function () {
  return gulp.src('./src/styles.css')
    .pipe(uglifycss({
      "uglyComments": true
    }))
    .pipe(gulp.dest('./dist/src'));
});

gulp.task("uglify", function () {
  return gulp.src("./src/index.js")
    // .pipe(rename("bundle.min.js")) // we can rename the file as well
    .pipe(uglify(/* options */))
    .pipe(gulp.dest("./dist/src"));
});

gulp.task('minifyHTML', async function () {
  gulp.src('./src/index.html')
    .pipe(htmlmin({ collapseWhitespace: true }))
    .pipe(gulp.dest('./dist/src'))
});

gulp.task('build', gulp.parallel('sass', 'css', 'uglify', 'minifyHTML', 'move'), function () {
  gulp.watch('./src/styles.scss', ['sass']);
  gulp.watch('./src/styles.css', ['css']);
  gulp.watch('./src/*.js', ['uglify']);
  gulp.watch('./src/*.html', ['minifyHTML']);
  gulp.watch(filesToMove, ['move'])
});
