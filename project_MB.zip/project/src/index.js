let MB = (function () {
	"use strict";

	/* catching all the objects and reused variables
	*/

	let defaults = {
		//handling bilingual
		en : {
			_addToCart : "Add To Cart",
			_removeFromShoppingBag : "Remove from Shopping Bag",
		},
		_endPoint : "./mocks/listHero.json",
		_records : [], // contain all the records after HTTP Call
		_updatedAmount : 0, // default add to cart amount
		$loader : document.querySelector(".loader"),
		$productList : document.querySelector("#product-list"),
		$carFilter : document.querySelector("#carFilter"),
		$noRecordFound : document.querySelector(".no-record-found")
	}

	/**
 * init function which will invoke on page load
 */
	const init = () => {
		_handleHTTP();
	}


	/**
  * handle HTTP function will handle all the HTTP request. Added setTimeout function to show the loader, however its not required generally.
  */

	const _handleHTTP = () => {
		// setTimeout used to show loader, otherwise not required
		setTimeout(function () {
			defaults.$loader.classList.add("hide");
			_getProductsList();
		}, 2000)

	}

	/**
  * getProductList function will make HTTP request to render product grid.
	* and once data received it will handle other function related to UI rendering and
	* and events
  */
	const _getProductsList = () => {

		fetch(defaults._endPoint)
			.then(data => {
				return data.json();
			})
			.then(res => {
				// adding _records  // contain all the records after HTTP Callin global variable i.e., _records  
				defaults._records = res  // contain all the records after HTTP Call //
				_handleProductGrid(res);
				_handleAction();
				_filterProduct();
			})
			.catch(e => {
				alert("Something went wrong :(")
				console.error(e)
			})
	}


	/**
  * handle product grid function  will create dynamic DOM elements and will append the
	* updated data in the DOM 
  */
	const _handleProductGrid = records => {
		defaults.$productList.innerHTML = "";

		records.forEach(element => {
			let $productListLi = document.createElement("li");
			let $productTitle = document.createElement("div");
			let $productImage = document.createElement("div");
			let $productPrice = document.createElement("div");
			let $button = document.createElement("button");

			//adding title
			$productTitle.classList.add("product-title");
			$productTitle.innerText = `${ element.modelClass } ${ element.version }`;

			//product image
			$productImage.classList.add("product-image");
			$productImage.innerHTML = `<img src="${ element.imagePath }" />`;

			//product price
			$productPrice.classList.add("product-price");
			$productPrice.innerHTML = `<span class="price"> ${ element.price.amount }</span> <span class="currency">&euro;</span>`;

			//button
			$button.classList.add("cta");
			$button.setAttribute("data-cart-in", defaults.en._addToCart);
			$button.setAttribute("data-cart-out", defaults.en._removeFromShoppingBag);
			$button.innerText = defaults.en._addToCart;

			$productListLi.appendChild($productTitle);
			$productListLi.appendChild($productImage);
			$productListLi.appendChild($productPrice);
			$productListLi.appendChild($button);
			defaults.$productList.appendChild($productListLi);
		});
	}

	/**
  * handle CTA function  will handle all the events related to Click to action button on UL. 
  */
	const _handleAction = () => {
			defaults.$productList.addEventListener("click", clickedButton => {
			if (clickedButton.target.classList.contains("cta")) {
				_handleClickCTA(clickedButton.target)
			}
		});
	}

	/**
  * handling specifically click functionality
  */
	const _handleClickCTA = button => {
		const productPrice = button.parentElement.querySelector(".product-price");
		const price = productPrice.querySelector(".price").innerText.split(",")[0];

		if (button.innerText === defaults.en._addToCart) {
			defaults._updatedAmount += parseFloat(price);

			button.innerText = defaults.en._removeFromShoppingBag;
			productPrice.classList.add("product-added");
			button.classList.add("product-added");

		} else {
			defaults._updatedAmount -= parseFloat(price);

			button.innerText = defaults.en._addToCart;
			productPrice.classList.remove("product-added");
			button.classList.remove("product-added");
		}


		const totalAmt = parseFloat(Math.round(defaults._updatedAmount * 100) / 100).toFixed(2);
		const totalPrice = document.querySelector("#totalPrice .price");
		totalPrice.innerText = parseInt(totalAmt) === 0 ? 0 : totalAmt;
	}

	/**
	 * handle filter functionality of the product. Handling below requirements
	 
	 * - When the user types a string longer than 3 characters then it filters the list by the car"s name (restoring it when less than 3 characters)
   * - When the user types a string which is not part of any car"s name a phrase saying "No cars with that name were found :(" should appear in the cars list area (as in [frame3.png](design/frame3.png))
	 */

	const _filterProduct = () => {
		defaults.$carFilter.addEventListener("keyup", () => {
			const searchQueryText = defaults.$carFilter.value.toUpperCase();
			const filteredRecords = defaults._records.filter(record => record.modelClass === searchQueryText);

			if (searchQueryText.length > 2) {
				if (filteredRecords.length) {
					_handleProductGrid(filteredRecords)
				} else {
					defaults.$noRecordFound.classList.remove("hide"); //hinding not found div
					defaults.$productList.classList.add("hide"); // showing results
				}

			} else if (searchQueryText.length < 3) {
				defaults.$noRecordFound.classList.add("hide");
				defaults.$productList.classList.remove("hide");
				_handleProductGrid(defaults._records)
			}
		})
	}

	return {
		init
	}
}());


// invoking dom ready function
MB.init()