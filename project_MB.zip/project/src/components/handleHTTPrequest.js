export function handleHTTPrequest (_endPoints) {

    fetch(_endPoints)
        .then(data => {
            return data.json()
        })
        .then(res => {
            return res
        })
}