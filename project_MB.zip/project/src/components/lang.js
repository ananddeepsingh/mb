var LANG = (function() {
  'use strict';

  return {
    publicMethod: function() {
      return { "a": 1}
    }
  };
}());
     
// LANG.publicMethod();