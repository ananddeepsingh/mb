const gulp = require('gulp');
const sass = require('gulp-sass');
const uglifycss = require('gulp-uglifycss');
const browserSync = require('browser-sync');
const uglify = require('gulp-jshint');


gulp.task('sass', function () {
  return gulp.src('./src/*.scss') 
    .pipe(sass())
    .pipe(gulp.dest('src'))
})

gulp.task('css', function () {
  return gulp.src('./src/styles.css')
    .pipe(uglifycss({
      "uglyComments": true
    }))
    .pipe(gulp.dest('./src'));
});

gulp.task('js', function () {
  return gulp.src('./src/index.js')
    .pipe(uglify())
    .pipe(gulp.dest('../dist'))
});
